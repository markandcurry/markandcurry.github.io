# Instructions

Please complete a code review on the JS, HTML, and CSS included with this README file.  Please include information on the following:

1. What is wrong with the JS, HTML, and CSS
2. What you would change
3. Why you would make the proposed changes

The exercise should take no longer than 30 minutes.

Thank you.